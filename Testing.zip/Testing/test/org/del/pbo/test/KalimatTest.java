/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.pbo.test;

import org.del.pbo.Kalimat;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import org.junit.experimental.categories.Category;

/**
 *
 * @author Astri Neva
 */
public class KalimatTest {
    Kalimat kalimat;
    
    public KalimatTest()
    {
        kalimat=new Kalimat("Saya pergi ke kampus del kemarin sore setelah gerbang del dibuka");
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testCountKataDel()
    {
        assertEquals(2, kalimat.countKataDel());
    }
    
    @Test
    @Category(StringReturn.class)
    public void testGetKataPertama()
    {
        assertEquals("Saya", kalimat.getKataPertama());
    }
    
    @Test
    @Category(StringReturn.class)
    public void testGetKataTerakhir()
    {
        assertEquals("dibuka", kalimat.getKataTerakhir());
    }
    @Test
    @Category(NonStringReturn.class)    
    public void testFindKataDel() 
    {
        assertEquals(true, kalimat.findKataDel("del"));
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testJumlahHuruf()
    {
        assertEquals(54, kalimat.jumlahHuruf());
    }
    
    @Test
    @Category(StringReturn.class)
    public void testKetJumlahHuruf()
    {
        assertEquals("Genap", kalimat.ketJumahHuruf());
    }
}
