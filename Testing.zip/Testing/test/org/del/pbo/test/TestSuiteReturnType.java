/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.pbo.test;

import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author Astri Neva
 */
@RunWith(Categories.class)
@Categories.IncludeCategory(NonStringReturn.class)
@Categories.ExcludeCategory(StringReturn.class)
//@Categories.IncludeCategory(StringReturn.class)
//@Categories.ExcludeCategory(NonStringReturn.class)

@Suite.SuiteClasses({BilanganTest.class, KalimatTest.class})
public class TestSuiteReturnType {
    
}
