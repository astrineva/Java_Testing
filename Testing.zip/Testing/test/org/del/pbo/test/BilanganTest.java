/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.pbo.test;

import org.del.pbo.Bilangan;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.experimental.categories.Category;

/**
 *
 * @author Astri Neva
 */
public class BilanganTest {
    private static int counterTest;
    private Bilangan bilangan;
    
    public BilanganTest()
    {
        bilangan=new Bilangan(2,0);
    }
    
    @BeforeClass
    public static void onceExecutedBeforeAll()
    {
        System.out.println("Persiapan Testing");
        counterTest=0;
    }
    
    @AfterClass
    public static void onceExecutedAfterAll()
    {
        System.out.println("Selesai testing dengan total "+counterTest+" unit test");
    }
    
    @Before
    public void executedBeforeEach()
    {
        System.out.println("Persiapan untuk test unit "+counterTest);
    }
    
    @After
    public void executedAfterEach()
    {
        System.out.println("Selesai melakukan test unit "+counterTest);
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPenjumlahanBenar()
    {
        assertEquals(2, bilangan.penjumlahan());
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPenjumlahanSalah()
    {
        assertNotEquals(5, bilangan.penjumlahan());
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPenguranganBenar()
    {
        assertEquals(2, bilangan.pengurangan());
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPenguranganSalah()
    {
        assertNotEquals(5, bilangan.pengurangan());
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPerkalianBenar()
    {
        assertEquals(0, bilangan.perkalian());
    }
    
    @Test
    @Category(NonStringReturn.class)
    public void testPerkalianSalah()
    {
        assertNotEquals(5, bilangan.perkalian());
    }
    
    @Test(expected=ArithmeticException.class)
    @Category(NonStringReturn.class)
    public void testPembagianException()
    {
        bilangan.pembagian();
    }
}
