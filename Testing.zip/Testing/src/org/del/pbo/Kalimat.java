/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.pbo;

/**
 *
 * @author Astri Neva
 */
public class Kalimat {

    private String kalimat;
    private int counter;
    int jlhHuruf = 0;

    public Kalimat() {

    }

    public Kalimat(String kalimat) {
        this.kalimat = kalimat;
    }

    public String getKataPertama() {
        return this.kalimat.split(" ")[0];
    }

    public String getKataTerakhir() {
        return this.kalimat.split(" ")[this.kalimat.split(" ").length - 1];
    }

    public boolean findKataDel(String kata) {
        return kata.equalsIgnoreCase("del");
    }

    public int countKataDel() {
        int i = 0;
        while (i < this.kalimat.split(" ").length) {
            if (findKataDel(this.kalimat.split(" ")[i])) {
                this.counter++;
            }
            i++;
        }
        return this.counter;
    }

    public int jumlahHuruf() {
        for (int k = 0; k < this.kalimat.length(); k++) {
            char ch = Character.toLowerCase(this.kalimat.charAt(k));
            if (Character.isLetter(ch)) {
                jlhHuruf++;
            }
        }
        return jlhHuruf;
    }
    
    public String ketJumahHuruf()
    {
        if (jlhHuruf % 2 == 0) {
            return "Genap";
        } else {
            return "Ganjil";
        }
    }
}
