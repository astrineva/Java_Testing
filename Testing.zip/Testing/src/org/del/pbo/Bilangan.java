/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.del.pbo;

/**
 *
 * @author Astri Neva
 */
public class Bilangan {

    private int a;
    private int b;

    public Bilangan() {

    }

    public Bilangan(int a, int b) {
        this.a = a;
        this.b = b;
    }

    public int penjumlahan() {
        return this.a + this.b;
    }

    public int penjumlahan(int a, int b) {
        return a + b;
    }

    public int pengurangan() {
        return this.a - this.b;
    }

    public int pengurangan(int a, int b) {
        return a - b;
    }

    public int perkalian() {
        return this.a * this.b;
    }

    public int perkalian(int a, int b) {
        return a * b;
    }

    public float pembagian() {
        try {
            return (float) (this.a / this.b);
        } catch (Exception ex) {
            throw (ex);
        }
    }

    public float pembagian(int a, int b) {
        return (float) (a / b);
    }
}
